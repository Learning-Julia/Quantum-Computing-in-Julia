﻿# Welcome!

The "Distinguish Unitaries" kata offers tasks in which you are given a unitary and have to figure out which of the list it is by designing and performing experiments on it.

You can [run the DistinguishUnitaries kata as a Jupyter Notebook](https://mybinder.org/v2/gh/Microsoft/QuantumKatas/main?filepath=DistinguishUnitaries%2FDistinguishUnitaries.ipynb)!